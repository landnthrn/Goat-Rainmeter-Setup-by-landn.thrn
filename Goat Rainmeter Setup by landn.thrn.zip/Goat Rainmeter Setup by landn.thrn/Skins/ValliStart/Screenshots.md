# Screenshots
ValliStart includes these pre-made layouts, but you are not limited to these!
![Vekl](https://user-images.githubusercontent.com/80020581/187899646-5ad099a5-3178-48a5-9661-c3967bd2cab4.png)
![WIn11 Alt](https://user-images.githubusercontent.com/80020581/187905490-e14533fc-3d3c-4161-8bdb-145e01ba132f.png)
![Win11](https://user-images.githubusercontent.com/80020581/187899649-be897e9b-e30c-4322-94df-2c387e45ba4a.png)
![Classic](https://user-images.githubusercontent.com/80020581/187899657-c4f513e2-7be1-4374-82cd-0aff2a2643d2.png)
![Flat](https://user-images.githubusercontent.com/80020581/187899658-43aa258d-6d94-4df2-8571-9b6e5d3b02cd.png)
![Side](https://user-images.githubusercontent.com/80020581/187899663-7d8c1bed-5522-4709-9698-33eb8fcf88cb.png)

